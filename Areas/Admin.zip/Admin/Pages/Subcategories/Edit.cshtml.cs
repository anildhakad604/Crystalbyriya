using CrystalByRiya.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace CrystalByRiya.Areas.Admin.Pages.Subcategories
{
    public class EditModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        public EditModel(ApplicationDbContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Subcategory Subcategory { get; set; }

        public async Task<IActionResult> OnGetAsync(int id)
        {
            Subcategory = await _context.TblSubcategory.FindAsync(id);

            if (Subcategory == null)
            {
                return NotFound();
            }

            return Page();
        }

       
        public async Task<IActionResult> OnPostAsync(string title)
        {
            Subcategory.MetaTitle = title;

            _context.Attach(Subcategory).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!SubcategoryExists(Subcategory.SubCategoryid))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return RedirectToPage("./Index");
        }

        private bool SubcategoryExists(int id)
        {
            return _context.TblSubcategory.Any(e => e.SubCategoryid == id);
        }
    }
}