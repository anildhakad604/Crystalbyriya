using CrystalByRiya.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Threading.Tasks;

namespace CrystalByRiya.Areas.Admin.Pages.Subcategories
{
    public class DeleteModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        public DeleteModel(ApplicationDbContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Subcategory Subcategory { get; set; }

        public async Task<IActionResult> OnGetAsync(int id)
        {
            Subcategory = await _context.TblSubcategory.FindAsync(id);

            if (Subcategory == null)
            {
                return NotFound();
            }

            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int id)
        {
            var subcategory = await _context.TblSubcategory.FindAsync(id);

            if (subcategory == null)
            {
                return NotFound();
            }

            _context.TblSubcategory.Remove(subcategory);
            await _context.SaveChangesAsync();
            return RedirectToPage("Index");
        }
    }
}
