using CrystalByRiya.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CrystalByRiya.Areas.Admin.Pages.Wishlist
{
    public class IndexModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        public IndexModel(ApplicationDbContext context)
        {
            _context = context;
        }

        public List<AddingWishlist> WishlistItems { get; set; }
        public List<SelectListItem> MarketingOptions { get; } = new List<SelectListItem>
        {
            new SelectListItem { Value = "Yes", Text = "Yes" },
            new SelectListItem { Value = "No", Text = "No" }
        };

        public async Task<IActionResult> OnGetAsync()
        {
            WishlistItems = await _context.TblWishlist.ToListAsync();
            return Page();
        }

        public async Task<IActionResult> OnPostUpdateMarketingAsync(int id, string marketing)
        {
            var wishlistItem = await _context.TblWishlist.FindAsync(id);
            if (wishlistItem == null)
            {
                return NotFound();
            }

            wishlistItem.Marketing = marketing;
            await _context.SaveChangesAsync();

            return RedirectToPage();
        }

    }
}
