using CrystalByRiya.Models;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;

namespace CrystalByRiya.Areas.Admin.Pages.CouponCodes
{
    public class CoupounCodeModel : PageModel
    {
        private readonly CrystalByRiya.Models.ApplicationDbContext _context;

        // Constructor to initialize the DbContext
        public CoupounCodeModel(CrystalByRiya.Models.ApplicationDbContext context)
        {
            _context = context;
        }

        // Property to store a list of coupon codes
        public List<TblCouponCode> CouponCodes { get; set; } = new List<TblCouponCode>();

        // Load the list of coupon codes on GET request
        
        public async Task<IActionResult> OnGetAsync()
        {
            // Fetch the list of coupon codes from the database
            CouponCodes = await _context.TblCouponCodes.ToListAsync();

            return Page();
        }
    }
}
