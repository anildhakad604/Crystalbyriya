using CrystalByRiya.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace CrystalByRiya.Areas.Admin.Pages.CouponCodes
{
    public class DeleteModel : PageModel
    {
        private readonly CrystalByRiya.Models.ApplicationDbContext _context;

        public DeleteModel(CrystalByRiya.Models.ApplicationDbContext context)
        {
            _context = context;
        }

        [BindProperty]
        public TblCouponCode CouponCode { get; set; }

        // Handle GET request to load the CouponCode for confirmation
        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            // Fetch the coupon code based on the id
            CouponCode = await _context.TblCouponCodes.FirstOrDefaultAsync(m => m.Id == id);

            if (CouponCode == null)
            {
                return NotFound();
            }

            return Page();
        }

        // Handle POST request to delete the CouponCode
        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            // Fetch the coupon code again to ensure it exists
            CouponCode = await _context.TblCouponCodes.FindAsync(id);

            if (CouponCode != null)
            {
                // Remove the coupon code from the database
                _context.TblCouponCodes.Remove(CouponCode);
                await _context.SaveChangesAsync();
            }

            // Redirect to the Index page after deletion
            return RedirectToPage("./Index");
        }
    }
}
