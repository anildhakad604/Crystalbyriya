using CrystalByRiya.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Threading.Tasks;

namespace CrystalByRiya.Areas.Admin.Pages.CouponCodes
{
    public class CreateModel : PageModel
    {
        private readonly CrystalByRiya.Models.ApplicationDbContext _context;

        public CreateModel(CrystalByRiya.Models.ApplicationDbContext context)
        {
            _context = context;
        }

        [BindProperty]
        public TblCouponCode CouponCode { get; set; }

        // Handle POST request to create a new CouponCode
        
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            // Add the new coupon code to the database
            _context.TblCouponCodes.Add(CouponCode);
            await _context.SaveChangesAsync();

            // Redirect to the Index page after successful creation
            return RedirectToPage("./Index");
        }
    }
}
