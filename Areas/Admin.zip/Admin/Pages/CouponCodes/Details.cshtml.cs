using CrystalByRiya.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace CrystalByRiya.Areas.Admin.Pages.CouponCodes
{
    public class DetailsModel : PageModel
    {
        private readonly CrystalByRiya.Models.ApplicationDbContext _context;

        public DetailsModel(CrystalByRiya.Models.ApplicationDbContext context)
        {
            _context = context;
        }

        public TblCouponCode CouponCode { get; set; }

        // Handle GET request to load the CouponCode details
        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            // Fetch the coupon code based on the id
            CouponCode = await _context.TblCouponCodes.FirstOrDefaultAsync(m => m.Id == id);

            if (CouponCode == null)
            {
                return NotFound();
            }

            return Page();
        }
    }
}
