using CrystalByRiya.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace CrystalByRiya.Areas.Admin.Pages.CouponCodes
{
    public class EditModel : PageModel
    {
        private readonly CrystalByRiya.Models.ApplicationDbContext _context;

        public EditModel(CrystalByRiya.Models.ApplicationDbContext context)
        {
            _context = context;
        }

        [BindProperty]
        public TblCouponCode CouponCode { get; set; }

        // Handle GET request to load the CouponCode for editing
        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            // Fetch the coupon code by id
            CouponCode = await _context.TblCouponCodes.FirstOrDefaultAsync(m => m.Id == id);

            if (CouponCode == null)
            {
                return NotFound();
            }

            return Page();
        }

        // Handle POST request to save the edited CouponCode
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            // Mark the entity as modified
            _context.Attach(CouponCode).State = EntityState.Modified;

            try
            {
                // Save changes to the database
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CouponCodeExists(CouponCode.Id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            // Redirect to Index page after successful edit
            return RedirectToPage("./Index");
        }

        // Check if CouponCode exists in the database
        private bool CouponCodeExists(int id)
        {
            return _context.TblCouponCodes.Any(e => e.Id == id);
        }
    }
}
