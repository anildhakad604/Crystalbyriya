﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using CrystalByRiya.Models;

namespace CrystalByRiya.Areas.Admin.Pages.Productsizes
{
    public class CreateModel : PageModel
    {
        private readonly CrystalByRiya.Models.ApplicationDbContext _context;
        private readonly IWebHostEnvironment _webHostEnvironment;

        public CreateModel(CrystalByRiya.Models.ApplicationDbContext context,IWebHostEnvironment webHostEnvironment)
        {
            _context = context;
            _webHostEnvironment = webHostEnvironment;
        }

        public IActionResult OnGet()
        {
            return Page();
        }

        [BindProperty]
        public ProductSizes ProductSizes { get; set; } = default!;

        // For more information, see https://aka.ms/RazorPagesCRUD.
        public async Task<IActionResult> OnPostAsync(IFormFile ImageUrl)
        {
            if (ImageUrl!= null && ImageUrl.Length > 1024 * 1024) // 1 MB in bytes
            {
                ModelState.AddModelError("Product.Thumbnail", "The thumbnail size must not exceed 1 MB.");
                return Page(); // Return to the page with the validation error
            }
           
            if (!ModelState.IsValid)
            {
                return Page();
            }
            string fileName = Guid.NewGuid().ToString() + Path.GetExtension(ImageUrl.FileName.Replace(' ', '-'));
            string filePath = Path.Combine(_webHostEnvironment.WebRootPath, "Images", fileName);

            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                await ImageUrl.CopyToAsync(stream);
            }
            ProductSizes.ImageURL=fileName;
          await  _context.TblProductSizes.AddAsync(ProductSizes);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }
    }
}
