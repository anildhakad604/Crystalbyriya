﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using CrystalByRiya.Models;

namespace CrystalByRiya.Areas.Admin.Pages.Gallery
{
    public class CreateModel : PageModel
    {
        private readonly CrystalByRiya.Models.ApplicationDbContext _context;
        private readonly IWebHostEnvironment _webHostEnvironment;


        public CreateModel(CrystalByRiya.Models.ApplicationDbContext context, IWebHostEnvironment webHostEnvironment)
        {
            _context = context;
            _webHostEnvironment = webHostEnvironment;
        }

        public IActionResult OnGet()
        {
            return Page();
        }

        [BindProperty]
        public ImageGallery ImageGallery { get; set; } = default!;

        // To protect from overposting attacks, see https://aka.ms/RazorPagesCRUD
        public async Task<IActionResult> OnPostAsync(List<IFormFile> Url)
        {

            foreach (var uploadedFile in Url)
            {
                if (uploadedFile.Length > 1024 * 1024) // 1 MB in bytes
                {
                    ModelState.AddModelError("Product.Thumbnail", "The thumbnail size must not exceed 1 MB.");
                    return Page(); // Return to the page with the validation error
                }
                // Create a unique file name to avoid conflicts
                string fileName = Guid.NewGuid().ToString() + Path.GetExtension(uploadedFile.FileName);
                string filePath = Path.Combine(_webHostEnvironment.WebRootPath, "Images", fileName);

                // Save the file to the wwwroot/Images folder
                using (var fileStream = new FileStream(filePath, FileMode.Create))
                {
                    await uploadedFile.CopyToAsync(fileStream);
                }

                // Save the image details to the database
                ImageGallery image = new ImageGallery()
                {
                    Productid = ImageGallery.Productid,
                    Url = fileName, // Save the filename, not the full path
                    Type = ImageGallery.Type,
                    AltText=ImageGallery.AltText
                   
                    
                };

                await  _context.TblImageGalleries.AddAsync(image);
                await _context.SaveChangesAsync();

            }

            return RedirectToPage("./Index");
        }
    }
}
